#include <iostream>
#include <string>

using namespace std;

int main()
{
	struct Date{
		int day;
		int month;
		int year;
		
	};
	
	struct VISTAVA {
		string Nazva = "";
		string Day_Week = "";
		double Cost;
		struct Date;
	};
	
	
	return 0;
}
